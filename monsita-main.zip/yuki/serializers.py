from rest_framework import serializers
from .models import *

class DetalleDonacionesSerializer(serializers.ModelSerializer):
    class Meta:
        model = DetalleDonaciones
        fields = '__all__'