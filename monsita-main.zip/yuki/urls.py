from . import views
from django.urls import path
from .views import *


urlpatterns = [
    path('', views.index, name="index"),
    path('interno/', views.interno, name="interno"),
    path("donaciones/", views.DetalleDonaciones, name="donaciones"),
    path("raza/", views.Raza, name="raza"),
    path("mascota/", views.mascota, name="mascota"),
    path("dadosadopcion/", views.DadosAdopcion, name="dadosadopcion"),
    path("citas/", views.Citass, name="citas"),
    path("vacunas/", views.vacunas, name="vacunas"),
    path("recursos/", views.Recursos, name="recursos"),
    path('donaciones_datatable/', DonacionesDatatableView.as_view(), name='donaciones_datatable'),
    path('raza_datatable/', RazaDatatableView.as_view(), name='raza_datatable'),
    path('mascota_datatable/', MascotaDatatableView.as_view(), name='mascota_datatable'),
    path('dadosadopcion_datatable/', MascotaAdopcionDatatableView.as_view(), name='dadosadopcion_datatable'),
    path('citas_datatable/', CitasDatatableView.as_view(), name='citas_datatable'),
    path('vacunas_datatable/', VacunasDatatableView.as_view(), name='vacunas_datatable'),
    path('recursos_datatable/', RecursosDatatableView.as_view(), name='recursos_datatable'),
    path("get-citas/", views.get_citas, name="get-citas"),
    path('confirmarCita/', confirmarCita.as_view(), name='confirmarCita'),
    path('cancelarCita/', CancelarCita.as_view(), name='cancelarCita'),
    path('reprogramarCita/', CancelarCita.as_view(), name='reprogramarCita'),
    path('get-user-info/', views.get_user_info, name='get_user_info'),
    path('donaciones_data/', views.donaciones_data, name='donaciones_data'),
    path('ruta-editar/<int:id>/', views.CrearAdopcion, name='editar_mascota'),
]
