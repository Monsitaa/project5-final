from django import forms 
from .models import *

class DetalleDonacionesForm(forms.ModelForm):
    class Meta:
        model = DetalleDonaciones
        exclude =  ('id', )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            field.widget.attrs.update({
                'class': 'form-control'
            })

class RazaForm(forms.ModelForm):
    class Meta:
        model = Raza
        exclude =  ('id', )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            field.widget.attrs.update({
                'class': 'form-control'
            })

class MascotaForm(forms.ModelForm):
    class Meta:
        model = Mascota
        exclude =  ('id', 'adopcion', )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            field.widget.attrs.update({
                'class': 'form-control'
            })

class DadosAdopcionForm(forms.ModelForm):
    class Meta:
        model = DadosAdopcion
        exclude =  ('id', )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            field.widget.attrs.update({
                'class': 'form-control'
            })

class CitasForm(forms.ModelForm):
    class Meta:
        model = Citas
        exclude =  ('id', )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            field.widget.attrs.update({
                'class': 'form-control'
            })

class VacunasForm(forms.ModelForm):
    class Meta:
        model = Vacunas
        exclude =  ('id', )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            field.widget.attrs.update({
                'class': 'form-control'
            })

class RecursosForm(forms.ModelForm):
    class Meta:
        model = Recursos
        exclude =  ('id', 'disponible', )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            field.widget.attrs.update({
                'class': 'form-control'
            })

class EditarMascotaForm(forms.ModelForm):
    class Meta:
        model = Mascota
        fields = ['nombre', 'peso', 'edad', 'Tamaño', 'raza', 'tipo', 'adopcion', 'foto']
        widgets = {
            'nombre': forms.TextInput(attrs={'class': 'form-control'}),
            'peso': forms.NumberInput(attrs={'class': 'form-control'}),
            'edad': forms.NumberInput(attrs={'class': 'form-control'}),
            'Tamaño': forms.NumberInput(attrs={'class': 'form-control'}),
            'raza': forms.Select(attrs={'class': 'form-control'}),
            'tipo': forms.Select(choices=clases, attrs={'class': 'form-control'}),  # Asegúrate de definir 'clases'
            'adopcion': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
            'foto': forms.FileInput(attrs={'class': 'form-control-file'})
        }