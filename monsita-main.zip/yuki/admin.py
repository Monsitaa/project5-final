from django.contrib import admin
from .models import *
# Register your models here.


admin.site.register(Mascota)
admin.site.register(Donaciones)
admin.site.register(DetalleDonaciones)
admin.site.register(Raza)
admin.site.register(DadosAdopcion)
admin.site.register(Citas)
admin.site.register(Vacunas)
admin.site.register(Recursos)