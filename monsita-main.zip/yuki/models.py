from django.db import models
from django.contrib.auth.models import User
# Create your models here.
import datetime

clases = [
    ("Gato", "Gato"),
    ("Perro", "Perro"),
]


class Donaciones(models.Model):
    usuario = models.ForeignKey(User, on_delete=models.CASCADE)
    cantidad = models.DecimalField(max_digits=10, decimal_places=2)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self) -> str:
        return f'{self.usuario}-{self.cantidad}'
    
class DetalleDonaciones(models.Model):
    donacionId = models.ForeignKey(Donaciones, on_delete=models.CASCADE)
    concepto = models.CharField(max_length=250)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self) -> str:
        return f'{self.donacionId}-{self.concepto}'
    
class Raza(models.Model):
    nombre = models.CharField(max_length=25)
    descripcion = models.CharField(max_length=125)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self) -> str:
        return f'{self.nombre}'
    
    
class Mascota(models.Model):
    nombre = models.CharField(max_length=20)
    peso = models.FloatField()
    edad = models.IntegerField()
    Tamaño = models.FloatField()
    raza = models.ForeignKey(Raza, on_delete=models.CASCADE)
    tipo = models.CharField(max_length=25, choices=clases, default="Perro")
    adopcion = models.BooleanField(default=False)
    foto = models.ImageField(upload_to='images/limon/', blank=True, default='default_image_url')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self) -> str:
        return f'{self.nombre}'
    
class DadosAdopcion(models.Model):
    mascota = models.ForeignKey(Mascota, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self) -> str:
        return f'{self.mascota}'

class Citas(models.Model):
    usuario = models.ForeignKey(User, on_delete=models.CASCADE)
    mascota = models.ForeignKey(Mascota, on_delete=models.CASCADE)
    fecha = models.DateField(default=datetime.date.today)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self) -> str:
        return f'{self.usuario}-{self.mascota}'
    
class Vacunas(models.Model):
    mascota = models.ForeignKey(Mascota, on_delete=models.CASCADE)
    nombre = models.CharField(max_length=50)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self) -> str:
        return f'{self.nombre}-{self.mascota}'
    

class Recursos(models.Model):
    nombre = models.CharField(max_length=50)
    cantidad = models.FloatField()
    disponible = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self) -> str:
        return f'{self.nombre}-{self.disponible}-{self.cantidad}'