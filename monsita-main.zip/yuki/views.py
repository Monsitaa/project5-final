from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse, JsonResponse
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from .forms import *
from rest_framework import viewsets
from .serializers import *
from django_datatables_view.base_datatable_view import BaseDatatableView
from .models import *
import json 
from django.core.mail import send_mail
from django.views import View
from django.views.decorators.csrf import csrf_exempt
from django.db.models import Sum, Count
from django.core.mail import EmailMultiAlternatives
from django.template.loader import render_to_string


# Create your views here.
# @login_required
def index(request):
    if request.method == 'GET':
        form = CitasForm()
        mascotas = Mascota.objects.filter(adopcion=False)
        
        context = {
            'form': form,
            'mascota': mascotas,
            
        }
        return render(request, "cliente/index.html", context)
    else:
        mascota_id = request.POST.get('mascota')
        fecha = request.POST.get('date')
        
        if not mascota_id or not fecha:
            return HttpResponse("Faltan campos obligatorios", status=400)
        
        try:
            fecha_datetime = datetime.datetime.fromisoformat(fecha)

            Citas.objects.create(
                usuario=request.user,
                mascota_id=mascota_id,
                fecha=fecha_datetime
            )
            
            return redirect('index')  

        except Exception as e:
            return HttpResponse(f"Error al guardar la cita: {e}", status=500)

class DonacionesDatatableView(BaseDatatableView):
    model = DetalleDonaciones
    columns = ['id', 'donacionId', 'concepto', 'created_at', 'updated_at']

    def render_column(self, row, column):
        if column == 'donacionId':
            return row.donacionId.id  
        return super(DonacionesDatatableView, self).render_column(row, column)

    def get_initial_queryset(self):
        return self.model.objects.all()
    
class RazaDatatableView(BaseDatatableView):
    model = Raza
    columns = ['id', 'nombre', 'descripcion', 'created_at', 'updated_at']

    def render_column(self, row, column):
        if column == 'nombre':
            return row.nombre
        return super(RazaDatatableView, self).render_column(row, column)

    def get_initial_queryset(self):
        return self.model.objects.all()
    
class MascotaDatatableView(BaseDatatableView):
    model = Mascota
    columns = ['id', 'nombre', 'peso', 'edad', 'Tamaño', 'raza__nombre', 'adopcion', 'foto', 'created_at', 'updated_at']

    def render_column(self, row, column):
        if column == 'raza__nombre':
            return row.raza.nombre  
        return super(MascotaDatatableView, self).render_column(row, column)

    def filter_queryset(self, qs):
        search_term = self.request.GET.get('search[value]', None)
        if search_term:
            qs = qs.filter(nombre__icontains=search_term)  
        return qs

class MascotaAdopcionDatatableView(BaseDatatableView):
    model = Mascota
    columns = ['id', 'nombre', 'peso', 'edad', 'tamaño', 'raza__nombre', 'tipo', 'adopcion', 'foto', 'created_at', 'updated_at']

    def render_column(self, row, column):
        if column == 'raza__nombre':
            return row.raza.nombre  
        return super(MascotaAdopcionDatatableView, self).render_column(row, column)

    def get_initial_queryset(self):
        return self.model.objects.filter(adopcion=True)
    
class CitasDatatableView(BaseDatatableView):
    model = Citas
    columns = ['id', 'usuario__username', 'mascota', 'created_at', 'updated_at']  

    def render_column(self, row, column):
        if column == 'usuario__username':
            return row.usuario.username  
        return super(CitasDatatableView, self).render_column(row, column)

    def get_initial_queryset(self):
        return self.model.objects.all()
    
class VacunasDatatableView(BaseDatatableView):
    model = Vacunas
    columns = ['id', 'mascota__nombre', 'nombre', 'created_at', 'updated_at'] 

    def render_column(self, row, column):
        if column == 'mascota__nombre':
            return row.mascota.nombre  
        return super(VacunasDatatableView, self).render_column(row, column)

    def get_initial_queryset(self):
        return self.model.objects.all()

class RecursosDatatableView(BaseDatatableView):
    model = Recursos
    columns = ['id', 'nombre', 'cantidad', 'disponible', 'created_at', 'updated_at']

    def render_column(self, row, column):
        if column == 'nombre':
            return row.nombre
        elif column == 'cantidad':
            return row.cantidad
        elif column == 'disponible':
            return "Disponible" if row.disponible else "No Disponible"
        elif column == 'created_at':
            return row.created_at.strftime('%Y-%m-%d %H:%M:%S')
        elif column == 'updated_at':
            return row.updated_at.strftime('%Y-%m-%d %H:%M:%S')
        return super(RecursosDatatableView, self).render_column(row, column)

    def get_initial_queryset(self):
        return self.model.objects.all()


@login_required
def interno(request):
    username = request.user.username
    donaciones = Donaciones.objects.all()
    total_donaciones = donaciones.aggregate(total_donaciones=Sum('cantidad'))['total_donaciones'] or 0
    cantidad_perritos = Mascota.objects.filter(tipo="Perro").count()
    cantidad_gatitos = Mascota.objects.filter(tipo="Gato").count()
    dados_adopcion = Mascota.objects.filter(adopcion=True).count()
    vacunas = Vacunas.objects.values('mascota').distinct().count()
    mascotas = Mascota.objects.all()
    context = {
        "usuario": username,
        'total_donaciones': total_donaciones,
        "cantidad_perritos": cantidad_perritos,
        "cantidad_gatitos": cantidad_gatitos,
        "dados_adopcion": dados_adopcion,
        "vacunas": vacunas,
        "mascotas": mascotas,
    }
    print(total_donaciones)
    return render(request, "interno/index.html", context)

@login_required
def DetalleDonaciones(request):
    if request.method == 'GET':
        form = DetalleDonacionesForm()
        donaciones = Donaciones.objects.all()
        context = {
            "form": form,
            'donaciones': donaciones,
        }
        return render(request, "interno/donaciones.html", context)
    else:
        form = DetalleDonacionesForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("donaciones")
        else:
            context = {
                "form": form,
            }
            return render(request, "interno/donaciones.html", context)
        

@login_required
def Raza(request):
    if request.method == 'GET':
        form = RazaForm()
        context = {
            "form": form,
        }
        return render(request, "interno/raza.html", context)
    else:
        form = RazaForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("raza")
        else:
            context = {
                "form": form,
            }
            return render(request, "interno/raza.html", context)
        
@login_required
def mascota(request):
    if request.method == 'GET':
        form = MascotaForm()
        context = {
            "form": form,
        }
        return render(request, "interno/mascota.html", context)
    else:
        form = MascotaForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect("mascota")
        else:
            context = {
                "form": form,
            }
            return render(request, "interno/mascota.html", context)
        
@login_required
def DadosAdopcion(request):
    if request.method == 'GET':
        form = DadosAdopcionForm()
        context = {
            "form": form,
        }
        return render(request, "interno/DadosAdopcion.html", context)
    # else:
    #     form = DadosAdopcionForm(request.POST)
    #     if form.is_valid():
    #         form.save()
    #         return redirect("dadosadopcion")
    #     else:
    #         context = {
    #             "form": form,
    #         }
    #         return render(request, "interno/DadosAdopcion.html", context)

@login_required
def Citass(request):
    if request.method == 'GET':
        form = CitasForm()
        context = {
            "form": form,
        }
        return render(request, "interno/Citas.html", context)
    else:
        form = CitasForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("citas")
        else:
            context = {
                "form": form,
            }
            return render(request, "interno/Citas.html", context)
        

def get_citas(request):
    citas = Citas.objects.all()  
    events = []
    for cita in citas:
        events.append({
            'title': f'{cita.mascota.nombre} - {cita.usuario.username}',
            'start': cita.created_at.isoformat(),
            'end': cita.updated_at.isoformat(),
            'description': f'Cita con {cita.mascota.nombre}',
            'user_email': cita.usuario.email,
            'mascota_foto': cita.mascota.foto.url if cita.mascota.foto else '',
        })
    return JsonResponse(events, safe=False)

        
@login_required
def vacunas(request):
    if request.method == 'GET':
        form = VacunasForm()
        context = {
            "form": form,
        }
        return render(request, "interno/Vacunas.html", context)
    else:
        form = VacunasForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("vacunas")
        else:
            context = {
                "form": form,
            }
            return render(request, "interno/Vacunas.html", context)
    
@login_required
def Recursos(request):
    if request.method == 'GET':
        form = RecursosForm()
        context = {
            "form": form,
        }
        return render(request, "interno/Recursos.html", context)
    else:
        form = RecursosForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("recursos")
        else:
            context = {
                "form": form,
            }
            return render(request, "interno/Recursos.html", context)


class confirmarCita(View):
    def post(self, request, *args, **kwargs):
        try:
            data = json.loads(request.body)
            subject = data.get('subject', 'No Subject')
            message = data.get('message', '')
            fecha = data.get('fecha', 'No Date')
            hora = data.get('hora', 'No Time')
            from_email = 'momeyhergod@gmail.com'
            recipient_list = data.get('recipient_list', [])
            
            if not recipient_list:
                return JsonResponse({'error': 'Recipient list is empty'}, status=400)
            
            html_content = render_to_string('interno/correos/confirmacion.html', {
                'subject': subject,
                'message': message,
                'fecha': fecha,
                'hora': hora,
            })

            email = EmailMultiAlternatives(subject, message, from_email, recipient_list)
            email.attach_alternative(html_content, "text/html")
            email.send()

            return JsonResponse({'success': 'Email sent successfully'})
        
        except json.JSONDecodeError:
            return JsonResponse({'error': 'Invalid JSON'}, status=400)
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)
        
class CancelarCita(View):
    def post(self, request, *args, **kwargs):
        try:
            data = json.loads(request.body)
            subject = data.get('subject', 'No Subject')
            message = data.get('message', '')
            fecha = data.get('fecha', 'No Date')
            hora = data.get('hora', 'No Time')
            from_email = 'momeyhergod@gmail.com'
            recipient_list = data.get('recipient_list', [])
            
            if not recipient_list:
                return JsonResponse({'error': 'Recipient list is empty'}, status=400)
            
            html_content = render_to_string('interno/correos/cancelacion.html', {
                'subject': subject,
                'message': message,
                'fecha': fecha,
                'hora': hora,
            })

            email = EmailMultiAlternatives(subject, message, from_email, recipient_list)
            email.attach_alternative(html_content, "text/html")
            email.send()

            return JsonResponse({'success': 'Email sent successfully'})
        
        except json.JSONDecodeError:
            return JsonResponse({'error': 'Invalid JSON'}, status=400)
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)
        
        
class ReprogramarCita(View):
    def post(self, request, *args, **kwargs):
        try:
            data = json.loads(request.body)
            subject = data.get('subject', 'No Subject')
            message = data.get('message', '')
            fecha = data.get('fecha', 'No Date')
            hora = data.get('hora', 'No Time')
            from_email = 'momeyhergod@gmail.com'
            recipient_list = data.get('recipient_list', [])
            
            if not recipient_list:
                return JsonResponse({'error': 'Recipient list is empty'}, status=400)
            
            html_content = render_to_string('interno/correos/reprogramacion.html', {
                'subject': subject,
                'message': message,
                'fecha': fecha,
                'hora': hora,
            })

            email = EmailMultiAlternatives(subject, message, from_email, recipient_list)
            email.attach_alternative(html_content, "text/html")
            email.send()

            return JsonResponse({'success': 'Email sent successfully'})
        
        except json.JSONDecodeError:
            return JsonResponse({'error': 'Invalid JSON'}, status=400)
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)
        

@csrf_exempt  
@login_required
def get_user_info(request):
    if request.user.is_authenticated:
        user_info = {
            'username': request.user.username,
            'email': request.user.email,
            'first_name': request.user.first_name,
            'last_name': request.user.last_name,
        }
        return JsonResponse(user_info)
    else:
        return JsonResponse({'error': 'User not authenticated'}, status=401)
    
def donaciones_data(request):
    donaciones = Donaciones.objects.filter(usuario=request.user)

    total_donaciones = donaciones.aggregate(total_donaciones=Sum('cantidad'))['total_donaciones'] or 0

    data = {
        'total_donaciones': total_donaciones,
        'usuario': request.user.username
    }

    return JsonResponse(data)

@login_required
def CrearAdopcion(request, id):
    mascota = get_object_or_404(Mascota, id=id)

    if request.method == 'POST':
        form = EditarMascotaForm(request.POST, request.FILES, instance=mascota)
        if form.is_valid():
            form.save()
            return redirect('mascota')
    else:
        form = EditarMascotaForm(instance=mascota)

    return render(request, 'interno/editarMascota.html', {'form': form})